<?php // layout/footer.php ?>
<footer class="footer border-top bg-white mt-4">
    <div class="container text-center">
        Platform kursus dengan alur:
        <em>Materi → Soal → Naik ke materi berikutnya</em>.
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
